// for constaint trigger...Run
http://localhost:8080/tritonlink/FTMweb_action.jsp?special=add_contraint_trigger

