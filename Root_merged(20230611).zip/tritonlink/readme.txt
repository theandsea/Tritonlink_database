// for constaint trigger...Run
// first change path in file FTMweb_action.jsp
res = FTM.path_execute_sql("/var/lib/tomcat9/webapps/ROOT/tritonlink/trigger_constraint.sql",conn.createStatement());
change the path to your absolute path of (/var/lib/tomcat9/webapps/ROOT/tritonlink/trigger_constraint.sql)
http://localhost:8080/tritonlink/FTMweb_action.jsp?special=add_contraint_trigger

