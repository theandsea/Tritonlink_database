-- add foreign key for enrollment, waitlist
ALTER TABLE enrollment
add FOREIGN KEY (c_number,section_id,s_year)
REFERENCES classes (c_number,section_id,s_year);

ALTER TABLE waitlist
add FOREIGN KEY (c_number,section_id,s_year)
REFERENCES classes (c_number,section_id,s_year);


SELECT y.c_number, x.f_name, z.quarter, z.s_year,grade
                                            FROM teaching x, enrollment y, classes z
                                                WHERE y.section_id = x.section_id AND
                                                    y.s_year = x.s_year AND
                                                    x.section_id = z.section_id AND
                                                    x.s_year = z.s_year AND
                                                    y.c_number = z.c_number;

-- delete the maintane
DROP TABLE IF EXISTS CPQG;
DROP TABLE IF EXISTS CPG;
DROP FUNCTION IF EXISTS insert_to_materialized_view;
DROP FUNCTION IF EXISTS update_to_materialized_view;
DROP FUNCTION IF EXISTS delete_to_materialized_view;
DROP TRIGGER IF EXISTS insert_trigger ON enrollment;
DROP TRIGGER IF EXISTS update_trigger ON enrollment;
DROP TRIGGER IF EXISTS delete_trigger ON enrollment;
DROP TABLE IF EXISTS grade_conversion;



-- add trigger
-- must use this, this is valid
CREATE OR REPLACE FUNCTION check_degree_constraint()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.school !~ '^U' THEN
        RAISE EXCEPTION 'Violation of constraint: School value must begin with "U".';
    END IF;


    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_degree_constraint_trigger
BEFORE INSERT ON degree
FOR EACH ROW
EXECUTE FUNCTION check_degree_constraint();



-- test
insert into degree(degree,school) values('BS', 'USTC');
insert into degree(degree,school) values('BS', 'MMM');
insert into degree(degree,school) values('BS', 'MMM');
select * from degree;
delete from degree where degree = 'BS' and school='MMM';
delete from degree where degree = 'BS' and school='UMMM';

-- remove trigger...if exists add after trigger...see the document in https://www.postgresql.org/docs/current/sql-droptrigger.html
DROP TRIGGER if exists check_degree_constraint_trigger on degree;



"CREATE TABLE weekly_Meeting("+
"section_id INT,"+
" s_year INT,"+
" m_type VARCHAR(50),"+
" m_day VARCHAR(50) NOT NULL,"+ // here within monday, tuesday....
" start_t TIME NOT NULL," +
" end_t TIME NOT NULL," +
" room VARCHAR(50) NOT NULL,"+
// " PRIMARY KEY(section_id,s_year,m_type),"+ // it should not have primary key
" FOREIGN KEY (section_id,s_year) REFERENCES section(section_id,s_year),"+
" CONSTRAINT m_check CHECK(m_type in ('LE','DI','LA','SE')),"+
" CONSTRAINT day_check CHECK(m_day in ('M','Tu','W','Th','F','Sa','Su')),"+
" CONSTRAINT st CHECK(start_t <= end_t),"+
" CONSTRAINT et CHECK(end_t >= start_t)"+
");"+







-- test if the serial works
CREATE temporary TABLE your_table_name (
    id SERIAL PRIMARY KEY,
    column1 int,
    column2 int
);



-- add serial for weekly_meeting and reviews, in case that they can update and delete
ALTER TABLE weekly_meeting
ADD COLUMN if not exists meeting_id SERIAL PRIMARY KEY;
ALTER TABLE review
ADD COLUMN if not exists review_id SERIAL PRIMARY KEY;





-- check for section enrollment limits ??? -- also for some
-- check both insert and update !!!...but without primary key, can't update, might overwrite several like weekly_meeting(same section_id, s_year, m_type, even m_day)...even can't delete, do not know which one to delete....every must has a primary key, relational must has foreign key as primary key(might not explicitly set, but must unique !!), if still not enough, must set extra !!!!!!!!!!!!!!!!!!!! or just disable update/delete ?? can't
-- update must check every row meeting the conditon(where)(that's why 2 notic), if no exception, then execute
-- maybe new.meeting_id = null if not specified, so that not has issue
CREATE OR REPLACE FUNCTION meeting_notsame()
RETURNS TRIGGER AS $$
DECLARE
its_id INT;
its_year int;
its_m_day varchar(50);
its_start time;
its_end time;
row_l int;
its_mid int;
BEGIN
    its_id := new.section_id;
    its_year := new.s_year;
    its_m_day := new.m_day;
    its_start := new.start_t;
    its_end := new.end_t;
    its_mid := new.meeting_id;
    RAISE NOTICE 'meeting_id #: %', its_mid;

    -- get all occupied time slot-->conflicting meeting with new one....also need to exclude itself !!!...other also need to exclude this
    create temporary table confliting_meeting as
    select m_day, start_t, end_t from weekly_meeting where section_id = its_id and meeting_id != its_mid  and s_year = its_year and its_m_day = m_day and ((its_start, its_end) OVERLAPS (start_t, end_t));

    row_l := 0;
    select count(*) into row_l from confliting_meeting;
    --RAISE NOTICE 'confliting_meeting #: %', row_l;

    IF row_l > 0 THEN
        RAISE NOTICE 'confliting_meeting #: %', row_l;
        RAISE EXCEPTION 'weekly meetings of the same section should not happen at same time';
    END IF;
    drop table confliting_meeting;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER meeting_notsame_
BEFORE INSERT or update ON weekly_meeting
FOR EACH ROW
EXECUTE FUNCTION meeting_notsame();


create temporary table confliting_meeting as
select m_day, start_t, end_t from weekly_meeting where section_id = '120'  and s_year = '2022' and m_day = 'M' and (('10:00:00'::time, '12:00:00'::time) OVERLAPS (start_t, end_t));


-- test
its_id := 120;
    -- its_year := 2023;
    -- its_m_day := 'M';
    -- its_start := '12:30:00';
    -- its_end := '12:50:00';
-- invalid
insert into weekly_meeting(section_id, s_year, m_type,m_day,start_t, end_t, room) values(120,2023, 'DI','M','09:30:00', '12:50:00', '');
delete from weekly_meeting where section_id = '120' and s_year='2023' and m_type ='DI'  and m_day='M' and start_t='09:30:00' and end_t='12:50:00';
--valid
insert into weekly_meeting(section_id, s_year, m_type,m_day,start_t, end_t, room) values(120,2023, 'DI','M','12:30:00', '12:50:00', '');
delete from weekly_meeting where section_id = '120' and s_year='2023' and m_type ='DI'  and m_day='M' and start_t='12:30:00' and end_t='12:50:00';
update weekly_meeting set start_t='12:30:00', end_t='12:50:00' where section_id = '132' and s_year='2023' and m_type ='LA' and m_day='M';
-- check
select * from weekly_meeting;

-- remove trigger...if exists add after trigger...see the document in https://www.postgresql.org/docs/current/sql-droptrigger.html
DROP TRIGGER if exists meeting_notsame_ on weekly_meeting;





























--
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0001','0001', '' ,'' ,'0001','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0002','0002', '' ,'' ,'0002','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0003','0003', '' ,'' ,'0003','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0004','0004', '' ,'' ,'0004','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0005','0005', '' ,'' ,'0005','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0006','0006', '' ,'' ,'0006','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0007','0007', '' ,'' ,'0007','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0008','0008', '' ,'' ,'0008','t','f');
insert into student(student_id, first_name, last_name, middle_name, social_security_num, is_enrolled, ca) values('0009','0009', '' ,'' ,'0009','t','f');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0001', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0002', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0003', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0004', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0005', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0006', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0007', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0008', 'CSE120', '120','2023','Letter','4','B');
insert into enrollment(student_id, c_number, section_id, s_year, option, units, grade)
values('0009', 'CSE120', '120','2023','Letter','4','B');

delete from enrollment where s_year = '2023' and section_id = '120' and student_id = '0001';
delete from enrollment where s_year = '2023' and section_id = '120' and student_id = '0002';




-- check for maximum enrollment
CREATE OR REPLACE FUNCTION enroll_limits()
RETURNS TRIGGER AS $$
DECLARE
its_std varchar(50);
its_id INT;
its_year int;
its_limit int;
row_l int;
BEGIN
    its_std := new.student_id;
    its_id := new.section_id;
    its_year := new.s_year;
    row_l := 0;
    its_limit:= 0;
    -- # (already enrolled)
    create temporary table enrolled as
    select student_id from enrollment where section_id = its_id and s_year = its_year;
    select count(*) into row_l from enrolled;
    -- # (enroll_limit)
    select enroll_limit into its_limit from section where section_id = its_id and s_year = its_year;
    -- check if already in....no need to check, already as primary key
    select count(*) into row_l from enrolled where student_id = its_std;
    IF row_l > 0 THEN
        RAISE EXCEPTION 'he/she has already enrolled this section';
    END IF;
    -- check exceed enroll_limit
    select count(*) into row_l from enrolled;
    if row_l >= its_limit then
        raise exception 'exceed the enrollment limits';
    end if;

    drop table enrolled;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER enroll_limits_
BEFORE INSERT or update ON enrollment
FOR EACH ROW
EXECUTE FUNCTION enroll_limits();
-- actually, here no need for update, since all involved for enrollment limit are primary key, can't update

-- check
select * from weekly_meeting;

-- remove trigger...if exists add after trigger...see the document in https://www.postgresql.org/docs/current/sql-droptrigger.html
DROP TRIGGER if exists enroll_limits_ on enrollment;

























-- check for professor's section's meeting not at same time
insert into faculty(name, department, title) values('Christ', 'CSE', 'prof');
insert into teaching(section_id, s_year, f_name) values('120','2023', 'Christ');
-- also review--actually Monday
insert into review(section_id, s_year, date, start_t, end_t) values('120','2023','2023-06-05','08:00:00','09:00:00');
insert into review(section_id, s_year, date, start_t, end_t) values('132','2023','2023-06-05','08:59:00','09:00:00');
-- also cross conflict
insert into weekly_meeting(section_id, s_year, m_type, m_day, start_t, end_t, room)
values ('120','2023','LA','M','08:00:00','09:00:00','');
insert into weekly_meeting(section_id, s_year, m_type, m_day, start_t, end_t, room)
values ('132','2023','LA','M','08:00:00','09:00:00','');
-- new try
insert into teaching(section_id, s_year, f_name) values('132','2023', 'Christ');


-- for testing cmd type in
its_q := 'Spring';
its_name := 'Christ';
its_year := '2023';
its_sid := '132';
row_l :=

-- get all section taught...but only same quarter...must use '', or take as column
create temporary table all_section as
select section_id from teaching where s_year = '2023' and f_name = 'Christ' and section_id in (select section_id from section where s_year = '2023' and quarter = 'Spring');
-- get all meetings--regular, review--already
create temporary table weekly_old as
select case m_day
        when 'M' then 1
        when 'Tu' then 2
        when 'W' then 3
        when 'Th' then 4
        when 'F' then 5
        when 'Sa' then 6
        when 'Su' then 7
        else null
       end as day
, start_t, end_t
from weekly_meeting where s_year = '2023' and section_id in (select section_id from all_section);
create temporary table single_old as
select date, start_t, end_t from review where s_year = '2023' and section_id in (select section_id from all_section);
-- get all meetings--regular--new
create temporary table weekly_new as
select case m_day
        when 'M' then 1
        when 'Tu' then 2
        when 'W' then 3
        when 'Th' then 4
        when 'F' then 5
        when 'Sa' then 6
        when 'Su' then 7
        else null
       end as day
, start_t, end_t
from weekly_meeting where s_year = '2023' and section_id = '132';
create temporary table single_new as
select date, start_t, end_t from review where s_year = '2023' and section_id = '132';
-- check conflicting between weekly_old and weekly_new
select count(*) into row_l from weekly_old where exists (select 1 from weekly_new where
weekly_old.day = weekly_new.day and ((weekly_new.start_t, weekly_new.end_t) OVERLAPS (weekly_old.start_t, weekly_old.end_t)));
IF row_l > 0 THEN
    RAISE EXCEPTION 'the new section has at least 1 confliction of weekly meeting with that of the sections already taught by the professor';
END IF;
-- check conflicting between weekly_old and single_new
select count(*) into row_l from weekly_old where exists (select 1 from single_new where
weekly_old.day = extract(dow from single_new.date) and ((single_new.start_t, single_new.end_t) OVERLAPS (weekly_old.start_t, weekly_old.end_t)));
IF row_l > 0 THEN
    RAISE EXCEPTION 'the new section has at least 1 confliction of review session with the weekly meetings of the sections already taught by the professor';
END IF;
-- check conflicting between single_old and weekly_new
select count(*) into row_l from single_old where exists (select 1 from weekly_new where
extract(dow from single_old.date) = weekly_new.day and ((weekly_new.start_t, weekly_new.end_t) OVERLAPS (single_old.start_t, single_old.end_t)));
IF row_l > 0 THEN
    RAISE EXCEPTION 'the new section has at least 1 confliction of weekly meeting with the review sessions of the sections already taught by the professor';
END IF;
-- check conflicting between single_old and single_new
select count(*) into row_l from single_old where exists (select 1 from single_new where
single_old.date = single_new.date and ((single_new.start_t, single_new.end_t) OVERLAPS (single_old.start_t, single_old.end_t)));
IF row_l > 0 THEN
    RAISE EXCEPTION 'the new section has at least 1 confliction of review session with that of the sections already taught by the professor';
END IF;
--drop table for late use
drop table all_section;
drop table weekly_old;
drop table weekly_new;
drop table single_old;
drop table single_new;






-- no need to squeeze, we can split to several time to type in the funciton if no enough space in cmd
-- also can't insert other weekly or review meeting ??? or just not multiple section ???
CREATE OR REPLACE FUNCTION teaching_notsame()
RETURNS TRIGGER AS $$
DECLARE
his_name varchar(50);
its_q varchar(50);
its_year int;
its_sid int;
row_l int;
BEGIN
    --initialize value
    his_name := new.f_name;
    its_year := new.s_year;
    its_sid := new.section_id;
    its_q := 'Spring';
    select quarter into its_q from section where s_year = its_year and section_id = its_sid;
    -- get all section taught...but only same quarter...must use '', or take as column
    create temporary table all_section as
    select section_id from teaching where s_year = its_year and f_name = his_name and section_id in (select section_id from section where s_year = its_year and quarter = its_q);
    -- get all meetings--regular, review--already
    create temporary table weekly_old as
    select case m_day
            when 'M' then 1
            when 'Tu' then 2
            when 'W' then 3
            when 'Th' then 4
            when 'F' then 5
            when 'Sa' then 6
            when 'Su' then 7
            else null
        end as day
    , start_t, end_t
    from weekly_meeting where s_year = its_year and section_id in (select section_id from all_section);
    create temporary table single_old as
    select date, start_t, end_t from review where s_year = its_year and section_id in (select section_id from all_section);
    -- get all meetings--regular--new
    create temporary table weekly_new as
    select case m_day
            when 'M' then 1
            when 'Tu' then 2
            when 'W' then 3
            when 'Th' then 4
            when 'F' then 5
            when 'Sa' then 6
            when 'Su' then 7
            else null
        end as day
    , start_t, end_t
    from weekly_meeting where s_year = its_year and section_id = its_sid;
    create temporary table single_new as
    select date, start_t, end_t from review where s_year = its_year and section_id = its_sid;
    -- check conflict
    row_l := 0;
    -- check conflicting between weekly_old and weekly_new
    select count(*) into row_l from weekly_old where exists (select 1 from weekly_new where
    weekly_old.day = weekly_new.day and ((weekly_new.start_t, weekly_new.end_t) OVERLAPS (weekly_old.start_t, weekly_old.end_t)));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new section has at least 1 confliction of weekly meeting with that of the sections already taught by the professor';
    END IF;
    -- check conflicting between weekly_old and single_new
    select count(*) into row_l from weekly_old where exists (select 1 from single_new where
    weekly_old.day = extract(dow from single_new.date) and ((single_new.start_t, single_new.end_t) OVERLAPS (weekly_old.start_t, weekly_old.end_t)));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new section has at least 1 confliction of review session with the weekly meetings of the sections already taught by the professor';
    END IF;
    -- check conflicting between single_old and weekly_new
    select count(*) into row_l from single_old where exists (select 1 from weekly_new where
    extract(dow from single_old.date) = weekly_new.day and ((weekly_new.start_t, weekly_new.end_t) OVERLAPS (single_old.start_t, single_old.end_t)));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new section has at least 1 confliction of weekly meeting with the review sessions of the sections already taught by the professor';
    END IF;
    -- check conflicting between single_old and single_new
    select count(*) into row_l from single_old where exists (select 1 from single_new where
    single_old.date = single_new.date and ((single_new.start_t, single_new.end_t) OVERLAPS (single_old.start_t, single_old.end_t)));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new section has at least 1 confliction of review session with that of the sections already taught by the professor';
    END IF;
    --drop table for late use
    drop table all_section;
    drop table weekly_old;
    drop table weekly_new;
    drop table single_old;
    drop table single_new;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER teaching_notsame_
BEFORE INSERT or update ON teaching
FOR EACH ROW
EXECUTE FUNCTION teaching_notsame();


-- test
insert into teaching(section_id, s_year, f_name) values('132','2023', 'Christ');
DROP TRIGGER if exists teaching_notsame_ on teaching;


















-- in case insert/update new weekly_meeting, cause confliction
CREATE OR REPLACE FUNCTION weekly_teach_notconflilct()
RETURNS TRIGGER AS $$
DECLARE
his_name varchar(50);
its_q varchar(50);
its_year int;
its_sid int;
its_start time;
its_end time;
its_m_day varchar(50);
its_day int;
its_mid int;
row_l int;
BEGIN
    --initialize value
    its_year := new.s_year;
    its_sid := new.section_id;
    its_mid := new.meeting_id;
    select f_name into his_name from teaching where s_year = its_year and section_id = its_sid;
    select quarter into its_q from section where s_year = its_year and section_id = its_sid;
    -- get all section taught...but only same quarter...must use '', or take as column
    create temporary table all_section as
    select section_id from teaching where s_year = its_year and f_name = his_name and section_id in (select section_id from section where s_year = its_year and quarter = its_q);
    -- get all meetings--regular, review--already... exclude the itself
    create temporary table weekly_old as
    select case m_day
            when 'M' then 1
            when 'Tu' then 2
            when 'W' then 3
            when 'Th' then 4
            when 'F' then 5
            when 'Sa' then 6
            when 'Su' then 7
            else null
        end as day
    , start_t, end_t
    from weekly_meeting where s_year = its_year and section_id in (select section_id from all_section) and meeting_id != its_mid;
    create temporary table single_old as
    select date, start_t, end_t from review where s_year = its_year and section_id in (select section_id from all_section);
    -- get new meetings--regular--new
    its_m_day := new.m_day;
    its_day := case its_m_day
            when 'M' then 1
            when 'Tu' then 2
            when 'W' then 3
            when 'Th' then 4
            when 'F' then 5
            when 'Sa' then 6
            when 'Su' then 7
            else null
        end;
    its_start := new.start_t;
    its_end := new.end_t;
    -- check conflict
    row_l := 0;
    -- check conflicting between weekly_old and weekly_new
    select count(*) into row_l from weekly_old where ((weekly_old.start_t, weekly_old.end_t) OVERLAPS (its_start, its_end)) and weekly_old.day = its_day;
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new weekly_meeting has at least 1 confliction with that of the sections already taught by the professor';
    END IF;
    -- check conflicting between single_old and weekly_new
    select count(*) into row_l from single_old where ((single_old.start_t, single_old.end_t) OVERLAPS (its_start, its_end)) and extract(dow from single_old.date) = its_day;
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new weekly_meeting has at least 1 confliction with the review sessions of the sections already taught by the professor';
    END IF;
    --drop table for late use
    drop table all_section;
    drop table weekly_old;
    drop table single_old;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER weekly_teach_notconflilct_
BEFORE INSERT or update ON weekly_meeting
FOR EACH ROW
EXECUTE FUNCTION weekly_teach_notconflilct();

-- drop
DROP TRIGGER if exists weekly_teach_notconflilct_ on weekly_meeting;
















































-- in case insert/update new review session, cause confliction
CREATE OR REPLACE FUNCTION review_conflict()
RETURNS TRIGGER AS $$
DECLARE
his_name varchar(50);
its_q varchar(50);
its_year int;
its_sid int;
its_start time;
its_end time;
its_date date;
its_rid int;
row_l int;
BEGIN
    --initialize value
    its_year := new.s_year;
    its_sid := new.section_id;
    its_rid := new.review_id;
    select f_name into his_name from teaching where s_year = its_year and section_id = its_sid;
    select quarter into its_q from section where s_year = its_year and section_id = its_sid;
    -- get all section taught...but only same quarter...must use '', or take as column
    create temporary table all_section as
    select section_id from teaching where s_year = its_year and f_name = his_name and section_id in (select section_id from section where s_year = its_year and quarter = its_q);
    -- get all meetings--regular, review--already
    create temporary table weekly_old as
    select case m_day
            when 'M' then 1
            when 'Tu' then 2
            when 'W' then 3
            when 'Th' then 4
            when 'F' then 5
            when 'Sa' then 6
            when 'Su' then 7
            else null
        end as day
    , start_t, end_t
    from weekly_meeting where s_year = its_year and section_id in (select section_id from all_section);
    create temporary table single_old as
    select date, start_t, end_t from review where s_year = its_year and section_id in (select section_id from all_section) and review_id != its_rid;
    -- get all meetings---new
    its_start := new.start_t;
    its_end := new.end_t;
    its_date := new.date;
    -- check conflict
    row_l := 0;
    -- check conflicting between weekly_old and single_new
    select count(*) into row_l from weekly_old where weekly_old.day = extract(dow from its_date) and ((weekly_old.start_t, weekly_old.end_t) OVERLAPS (its_start, its_end));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new review session has at least 1 confliction with the weekly meetings of the sections already taught by the professor';
    END IF;
    -- check conflicting between single_old and single_new
    select count(*) into row_l from single_old where single_old.date = its_date and ((its_start, its_end) OVERLAPS (single_old.start_t, single_old.end_t));
    IF row_l > 0 THEN
        RAISE EXCEPTION 'the new review session has at least 1 confliction with that of the sections already taught by the professor';
    END IF;
    --drop table for late use
    drop table all_section;
    drop table weekly_old;
    drop table single_old;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER review_conflict_
BEFORE INSERT or update ON review
FOR EACH ROW
EXECUTE FUNCTION review_conflict();


-- drop
DROP TRIGGER if exists review_conflict_ on review;



