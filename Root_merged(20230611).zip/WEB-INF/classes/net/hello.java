package net;

public class hello {
    /* */
    public static void main(String[] args) {
        // System.out.println("Hello, World!");
        // System.out.println(xxx());
        System.out.println(xxx());
    }

    // with package net... get to direction containing net
    // javac net/hello.java
    // java net/hello
    public static String xxx(){
        return "Hello, World!";
    }
}
